// // let a=Number(prompt("enter the number:"))
// // let b=Number(prompt("enter the number:"))
// // let c=Number(prompt("enter the number:"))
// // sum=a+b+c

// // console.log(sum);
// // avg=(a+b+c)/3
// // console.log(avg);

// // ************ refrecnce copy******************
// let a=[8,7,5]
// let b=a
// b.push(10)
// console.log(a)
// console.log(b);
// // ********************* shellow copy****************

// let a1=[8,4,9,3]
// let b1=[...a]
// b1.push(56)
// console.log(a1)
// console.log(b1);
// //************* merge obj ********************** */
// const obj1={ 1:"a",2:"v"}
// const obj2={ 3:"u",4:"i"}
// const obj3={...obj1,...obj2}
// console.log(obj3);
 


// function add(a,b,c){
//     return (a+b+c)
// }
// let arr=[2,4,1]
// console.log(add(...arr));

// //********** nullish************ */

// let x=0;
// let y=10
// let z=x??y
// console.log(z);
// //**************** optional chain************* */

// let abc={
//     name:
// }

