// Menu icon toggle code
let menuIcon = document.querySelector("#menu-icon");
let navLinks = document.querySelector(".nav-links");

menuIcon.addEventListener("click", () => {
  navLinks.classList.toggle("active");

  // icon change hamburger <-> cross
  menuIcon.classList.toggle("fa-bars");
  menuIcon.classList.toggle("fa-xmark");
});

// Nav links click hone par menu close
document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("active");
    menuIcon.classList.add("fa-bars");
    menuIcon.classList.remove("fa-xmark");
  });
});

// ================= Progress Bar ==================
document.querySelectorAll(".progress").forEach(progress => {
  let skillValue = progress.getAttribute("data-skill");

  // Bar ki width set karo
  progress.style.width = skillValue + "%";

  // Percentage text create karo
  let percentageText = document.createElement("span");
  percentageText.classList.add("percentage-text");
  percentageText.innerText = skillValue + "%";

  // Progress bar ke andar append karo
  progress.appendChild(percentageText);
});
