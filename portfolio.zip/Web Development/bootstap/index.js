
// var a;
// var a=29// redeclaration
// var a=23// reassignment
// console.log(a);

// let a;
// a=10
// console.log(a);

// function F1()
// {
//     var x=20;
//     x=20;
//     console.log(x);
    

// }
// F1()


// let a=9.4;
// console.log(typeof(a));

// let name="asdff"
// console.log(typeof(name));
// let a=Number(prompt("enter the number:"))
// let b=Number(prompt("enter the number:"))
// let c=Number(prompt("enter the number:"))
// sum=a+b+c

// console.log(sum);
// avg=(a+b+c)/3
// console.log(avg);
let a=document.getElementById("one")
console.log(a);
a.style.color="red"
a.innerText="updated text"

function setmood(e){
    document.getElementById("emoji").innerText=e;

}
function seeemoji(a){
    document.getElementById("para").innerText="👌"

}
function add(){
     let h1=document.createElement("h1");
     h1.innerText="❤️";
     //console.log(h1);
     document.body.appendChild(h1);

     

}
function submitform(){
    let name=document.getElementById('name').value;
    let password=document.getElementById('password').value;

    if(name==="" || password===" "){
        alert("all fields are requried")
        return false;
    }
    else{
        alert("form submit")
        return true;

    }
}