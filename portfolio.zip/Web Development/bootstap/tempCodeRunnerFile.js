var a;
// var a=29// redeclaration
// var a=23// reassignment
// console.log(a);