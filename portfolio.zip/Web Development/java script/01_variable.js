const accountId = 1234
let accountEmail = "kumaraanand.9380@gmail.com"
var accountPassword = "23456"
accountCity = "jaipur" 
let accountstate //kisi variable ko declare kane ke bad usme koi value assing na kare to wah by defualt undefined leta hai
// accountId = 2// not allowed
accountEmail="anandrdgv@gmail.com"
accountPassword = "8975"
accountCity = "kanpur"
// console.log(accountId);
// console.log(accountEmail);
// console.log(accountPassword);
// console.log(accountCity);
//durasa tarika
console.table([accountId , accountEmail , accountPassword, accountCity, accountstate])
// prefer not to use var . because of issue in block scpoe and functional scpoe.
