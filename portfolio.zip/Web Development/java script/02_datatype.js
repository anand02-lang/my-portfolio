"use strict"; //treat all js code as newer version
// alert(3+3) // we are not using nodejs ,not brower
let name="aman"
let age=20
let isLoggedIn=true

//types of data type
//number => 2 to power 53
//bigint
//string => " "
//boolean => true/false
//null => standalone value
//undefined => abhi value assing nahi hui hai
//symbol =>unique 


//object
console.log(typeof undefined);//undefine 
console.log(typeof null);//object
