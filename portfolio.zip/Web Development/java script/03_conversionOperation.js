// let score = "53aa"

// console.log(typeof score)
// console.log(typeof (score)) // dono same hai

// let valueInNumber = Number(score);
// console.log(typeof valueInNumber);
// console.log(valueInNumber);
// let score = null

// console.log(typeof score)
// console.log(typeof (score)) // dono same hai

// let valueInNumber = Number(score);
// console.log(typeof valueInNumber);
// console.log(valueInNumber);

//*********************************conversion in number**********************
// "33" => 33
//"33acx" =>NaN (not a number)
//ture => 1; false => 0
//undefine => NaN
//null => 0
//string => NaN

// let isLoggedIn = "anand"
// let booleanIsLoggedIn = Boolean(isLoggedIn)
// console.log(booleanIsLoggedIn); 

//*************************conversion in boolean*********************
//1 => true ; 0 => false
//""=> false
//"anand" => true

// let someNumber = 33
// let stringNumber = String(someNumber)
// console.log(stringNumber);
// console.log( typeof stringNumber);
 
//**********************operation*****************************/

let value = 3
let negvalue = -value
// console.log(negvalue)

// console.log(2+2)
// console.log(2-2)
// console.log(2*2)
// console.log(2**2)
// console.log(2/2)
// console.log(2%2)

 let str1 = "hello"
 let str2 = " Anand"
// let str3 = console.log(str1+str2);

// console.log("3"+4);
// console.log(3+"4");
// console.log("3"+4+5);
// console.log(3+4+"5");
// console.log(3+4*6%4);

// console.log(+true);
// console.log(+"");

let num1 ,num2, num3
// num = num1 = num2 = num3 = 2+2

// let gamecounter = 100
// // gamecounter++;
// ++gamecounter;
// console.log(gamecounter);
