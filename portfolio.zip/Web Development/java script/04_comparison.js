// console.log(2<1);
// console.log(2>1);
// console.log(2<=1);
// console.log(2==1);
// console.log(2!=1);

// console.log("3">2);
// console.log("03">2);


console.log(null>0);
console.log(null==0);
console.log(null>=0);

console.log(undefined==0);

//stric check (===)
console.log("2"===2)

