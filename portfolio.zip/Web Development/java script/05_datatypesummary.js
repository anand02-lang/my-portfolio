//primitive data type

//7 type : string , number, boolean, null, undefine, symbol,bigInt

const score = 100
const scoreValue = 100.4

const isLoggedIn = false
const outsideTemp = null
let useEmail;

const id = Symbol('123')
const anotherId = Symbol('123')

console.log(id==anotherId);

// const bigNumber = 957738322223n


//Reference (Non primitive data type)
//array , obeject, functions

const heros = ["shaktiman","naagraj","doga"]
let myObj = {
    name : "anand",
    age : 22,
}

const myFunction = function(){
    console.log("Hello world");
}

console.log(typeof outsideTemp)
console.log(typeof myFunction);
console.log(typeof id);
console.log(typeof anotherId);


//************************ Memory ************************************ */
// stack(primitive),Heap(Non-primitive)
let myYoutubename = "anandsharma"
let anothername = myYoutubename
anothername = "chaiaurcode"

console.log(myYoutubename);
console.log(anothername);
let userOne = {
    email:"anand@gmail.com",
    upi:"user@3"

}
let userTwo =userOne;
userTwo.email = "anand@gmail.com"
console.log(userOne.email);
console.log(userTwo.email);

