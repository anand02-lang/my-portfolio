const score = 400
//console.log(score);

const balance = new Number(100)// spacific cast kiya hai ki yah number hai
//console.log(balance);

//console.log(balance.toString().length);//convert the number to string
// console.log(balance.toFixed(3));//number decimal me convert hota hai

const otherNumber = 123.843
//console.log(otherNumber.toPrecision(3));//precision

const hundreds = 1000000
// console.log(hundreds.toLocaleString('en-IN'));//indian language me convert
//console.log(hundreds.toLocaleString());//US language me convert

//***************** maths ****************************** */

// console.log(Math);
// console.log(Math.abs(-3));//convert the negative sign to positive sign
// console.log(Math.round(4.7));//roundof
// console.log(Math.ceil(4.1)); //consider the upper value
// console.log(Math.floor(4.9));//consider the lower value
// console.log(Math.min(3,5,6,7,9));
// console.log(Math.max(3,5,6,7,9));


console.log(Math.random()); // value ka range 0 to 1 
console.log(Math.random()*10);//left side ek digit shift ho jata hai
console.log((Math.random()*10)+1);//eski minimum value one nahi ho sakti kabhi bhi zero nahi ho sakti hai


const min = 10;
const max = 20;
 
console.log(Math.floor(Math.random()*(max - min + 1)) + min);





