//*****************************date*******************************

let myDate = new Date();
// console.log(myDate.toString());
// console.log(myDate.toDateString());
// console.log(myDate.toJSON());
// console.log(myDate.toLocaleDateString());
// console.log(myDate.toLocaleString());
// console.log(typeof myDate);

// let myCreatedDate = new Date(2023,0,12);//js me mounth zero se start hote hai (only date syntex)
//let myCreatedDate = new Date(2023,0,13,5,3,7); //(date and time syntex)
// let myCreatedDate = new Date("2025-01-05");//(yyyy-mm-dd syntex)
let myCreatedDate = new Date("05-03-2024");//(dd-mm-yyyy) use in india
//console.log(myCreatedDate.toLocaleString());


//********************************** Time*********************   */

 let myTimeStamp =  Date.now();//new Date() are same
// console.log(myTimeStamp);// time in millsecond
// console.log(myCreatedDate.getTime()); // convert date to time(millsecond)
// console.log(Math.floor(Date.now()/1000));//convert the time millsecond to second
 

let newDate = new Date();
console.log(newDate);
console.log(newDate.getMonth()+1);
console.log(newDate.getDay());

console.log(newDate.toLocaleString('default',{
    weekday:"long"
}))




