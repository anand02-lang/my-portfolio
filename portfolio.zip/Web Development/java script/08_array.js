//*********************  Array************************ */

const myArray = [0 ,1 ,2 ,3 ,4, 5 ]
const myHeros = ["shaktiman" , "naagraj"]

const myArray2 = new Array(1,2,3,4,5)
//console.log(myArray[0]);

//************ Methods************** */

// myArray.push(6);// array me value ko add karta hai  last me 
// myArray.pop();//array me value ko remove karta hai  last value ko
// myArray.unshift(1);//array me value ko add karta hai  starting me 
// myArray.shift();//array me value ko remove karta hai starting value ko
// console.log(myArray.includes(6));//questions
// console.log(myArray.indexOf(5));

// const newArray = myArray.join();//convert the array to string
// console.log(myArray);

// console.log(newArray);
// console.log(typeof newArray);


// **********slice and splice methods***************

console.log("A ",myArray);

const myn1 = myArray.slice(1,3);//range 0 to 2
console.log(myn1);

console.log("B ",myArray);

const myn2 = myArray.splice(1,3);///range 0 to 3 and // array ko tod  deta hai
console.log("C ",myArray);

console.log(myn2);

