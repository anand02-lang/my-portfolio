const marval_heros = ["thor", "ironman", "spiderman"]
const dc_heros = ["superman", "flash", "batman"]
 //marval_heros.push(dc_heros); // two array not merage 
 //console.log(marval_heros); 
//console.log(marval_heros[3][1]);
const all_arr =marval_heros.concat(dc_heros);//concat two ko merge karta hai
// console.log(all_arr);
 
//********spired*** array ko merge karne ka essay way****** */

const all_new_arr = [...all_arr,...dc_heros];
//console.log(all_new_arr);

const another_array = [1, 2, 3, [4, 5, 6], 7, [8, 9, [4, 7,  9]]];
const real_another_array = another_array.flat(Infinity);// all sub array ko merge karke ek new array return 
//console.log(real_another_array);


const arr1 = Array.isArray("anand");
console.log(arr1);

const arr2 = Array.from("anand") ///  convert the iterable obj to array
console.log(arr2);
 
const arr3 = Array.from({name: "anand"}) // not convert array
console.log(arr3);


let score1 = 100
let score2 = 200
let score3 = 300
 score4 = Array.of(score1, score2, score3); // set of element ko convert to array
console.log(score4);

