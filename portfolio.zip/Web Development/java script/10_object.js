// Singleton

//object literals

  //Object literals => singleton nahi banta 

  const mySymbol = Symbol("key1");

  const JsUser = {
    name: "Anand",
    "full name":"Anand Sharma",// ab ye dot se excess nahi hoga
    [mySymbol]: "key1",// syntex  symbol declare in object 
    age: 18,
    location: "akbarpur",
    email: "anandsharma@gmail.com",
    isLoggedIn: "false",
    lastLoginDays:["Monday","saturday"]
  }
 //console.log(JsUser.email);//  it is not good way to excess the object
 
 console.log(JsUser["email"]);
 console.log(JsUser["full name"]);
 console.log( JsUser[mySymbol]);
 

 JsUser.name = "sharma" // object ki value ko change kar sakte hai
 //Object.freeze(JsUser) // object ko lock karte hai changr na ho
 JsUser.name=" aman"
 //console.log(JsUser);
 

 // **************object me function  add karna ************
 JsUser.greeting = function(){
    console.log(" hello js world");
    
 }
 console.log(JsUser.greeting());
 
 JsUser.greetingTwo = function(){
    console.log( `hello js world , ${this.name}`);
 }
 console.log(JsUser.greetingTwo());
 
