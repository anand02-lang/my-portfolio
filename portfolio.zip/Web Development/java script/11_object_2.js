// constructor => singalton kar sakte hai

//Constructor

//const tinderUser = new Object()  ///  singalton object hai
const tinderUser = {}  // not  singalton object 
tinderUser.id = "123qwe"
tinderUser.name = "Anand"
tinderUser.isLoggedIn = false

//console.log(tinderUser);

const regularUser = {
    email: "amezon@gmail.com",
    fullname: { 
        userfullname:{
            firstname: "Anand",
            lastname:"Sharma",
        }

    }
}
console.log(regularUser.fullname.userfullname.firstname);


//  *********************Merge Object **********************

const obj1 = {1: "a", 2: "b"}
const obj2 = {3: "c", 4: "d"}
const obj3 = {5: "e", 6: "f"}
//const obj4 = {obj1, obj2, obj3}  // obj me obj a gaye this is worng

//const obj4 = Object.assign({}, obj1, obj2, obj3)// this is not good method 


const obj4 = {...obj1, ...obj2, ...obj3} // using spired

//console.log(obj4);


/// **********array me object***************

const users = [
    {
        id: 1,
        email:"anand@gmail.com"
    },
      {
        id: 1,
        email:"anand@gmail.com"
    },
      {
        id: 1,
        email:"anand@gmail.com"
    },
]
users[1].email
console.log(tinderUser);

//console.log(Object.keys(tinderUser));
//console.log(Object.values(tinderUser));
//console.log(Object.entries(tinderUser));

//console.log(tinderUser.hasOwnProperty("isLoggedIn"));// obj me vlue hai ya nahi pata chalta hai


//********** obj de - structure****************** */

const course = {
    coursename: "js in hindi",
    courseteacher: "hitsh",
    price:"999",

}
course.coursename //  value instract kar sakte hai this is not good way
const {courseteacher: teacher} = course // object ka de - structure   this is good way
//console.log(courseteacher);
//console.log(teacher);



//************* API************* */
//***JSON********** */
// {
//     "name": "Anand",
//     "coursename": "js in hindi",
//     "price": "free"
// }

