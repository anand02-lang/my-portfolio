//using function 
function sayMyName(){
console.log("A");
console.log("N");
console.log("A");
console.log("N");
console.log("D");
}                    ///  function diffination

//sayMyName()   // function reffernce

// function addTwoNumber(number1 , number2){
//     console.log(number1 + number2);
    
// }
//addTwoNumber(3,6)
function addTwoNumber(number1 , number2){
    let result = number1 + number2;
    return result;
    console.log("Anand");// function me return ke bad kuch bhi print nahi hota hai 
    
    
}
 const result = addTwoNumber(3,6)
 //console.log("Result:" ,result);


 function loginUserMessage(username){
    if(username === undefined)
    {
        //console.log("please enter the username");
        return
        
    }
    return `${username} just logged in`
 }
 //console.log(loginUserMessage("Anand sharma"))
 //console.log(loginUserMessage(""))//empty string
 //console.log(loginUserMessage())// kuch na pass kare { tab result ata undefine}
 

  function CalculateCartPrice( val1, val2, ...num1) // rest opretor (..num)
  {
    return num1
  }
  console.log(CalculateCartPrice(4, 7, 78, 567)) // many value pass kar rahe hai

  /**************** object ko function me pass*************** */

  const user = {
    username: "Anand",
    price: 999

  }
  function handleObject(anyobject)// koi bhi obj aa sakta hai
  {
    console.log(`Username is ${anyobject.username} and price is ${ anyobject.price}`);
    

  }
  //handleObject(user)

  handleObject({
    username: "sharma",
    price:499
  })      //second method

  //*************array ko function me pass ************** */

  const myNewArray = [200,400,500,600]

  function returnSecondValue(getArray){
    return getArray[3]
  }
  //console.log(returnSecondValue(myNewArray));
  
  console.log(returnSecondValue([200,400,500,600]));