// let a=29
// const b=90
// var c=80
//var c=300  //global scope
let a=300
if(true)
    {
        let a=29
        const b=90
        //var c=80
    }              // global scope me likhi value scope me aviable hoti hai scope ki value bahar nahi jani chahiye
console.log(a);
//console.log(b);
//console.log(c);


//*********** nested scope*************** */

// using function

function one(){
    const username = "Anand"
    function two(){
        const website = "google"
        console.log(username);
        
    }
   // console.log(website);  website scope ke bahar hai
    
    two()
}

one()


//using if else
    
    if(true){
        const user = "Sharma"
        if(true){
            const site = "youtube"
            console.log(user + site);
            
        }
        //console.log(site);  scope ke bahar hai
        
    }
    //console.log(user); scope ke bahar hai

    //************ important*************** */

    console.log(addOne(5)); // addone ko access kar sakta hai

    function addOne(num){
        return num + 1
    }
    

    //addTwo(6)// addtwo ko access nahi kar sakta hai
    const addTwo = function(num){
        return num + 2
    }
    addTwo(6)
    console.log(addTwo(6));
    