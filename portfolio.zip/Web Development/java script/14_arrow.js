//************************ this keyword**************************

const user = {
    username: "Anand",
    price: 800,

    welcomeMessage: function(){
        console.log(`${this.username},welcome to website`);// this=>current context => obj ke scope me  variable ko access karta hai
        console.log(this);// current context display karta hai  obj me hai kya 
        
    }

}
//user.welcomeMessage()
//user.username="sharma"// current context ki value change ho gai hai
//user.welcomeMessage()

//console.log(this);//empty obj
// browers ke andar global obj=> window obj hai

//****************using function ***************88 */
 //function chai(){
     //let username="anand_sharma"
     //console.log(this.username); // o/p-> undefine    [ this keyword ka use only obj me hi hota hai function me nahi]

    
 //}
// chai()

// const chai=function(){
//     let username="anand"
//     console.log(this.username);//o/p-> undefine
    
// }
// chai()


// **********************using arrow function*******************

const chai = () =>{   //  arrow function 
    let username = "anand"
    console.log(this.username); //o/p-> undefine
    
} 
//chai()

() =>{} // basic decleartion fo arrow function
  // const addTwo=(num1 , num2) =>{  // arrow function ko name/variable ke andar hold kar sakte hai  //  ye basic arrow function
 //     return (num1 + num2)

//}

// ***************** implicit  return -> arrow function => ({}) parathisis not use  and not write return keyword **************

//const addTwo =(num1 ,num2) =>  (num1+num2)

// ********** explicit return  => me return keyword use hota hai******************



//  ************** implicit return => obj ko return karna hai*********

const addTwo =(num1,num2)=>({username:"anand"}) //  obj ko return karne ki liye () lagana padega
console.log(addTwo(4,9));