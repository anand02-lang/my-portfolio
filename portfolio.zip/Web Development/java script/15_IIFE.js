// ***  Immediately INvoked Function Expressions (IIFE)**********

// function chai(){
//     console.log(`anand`);
    
// }
//chai()

// *********** using (IIFE) =>  global scope ke pollution ko hatane ke liye use kiya jatahai
 // named IIFE
(function chai(){
    console.log(`anand`);
    
})();

// code ko end hone keliye use karte hai (;) semicolon ka

//  syntex  =>  () -> function ki definetion and () -> excution call

// *********** using arrow function *****

( () =>{
    console.log(`sharma`);
    
})();
 // variable pass karna ho tab
 // unnamed IIFE
( (name) =>{
    console.log(`sharma ${name}`);
    
})('swati')