//**************** if - else statement***************** */

// > ,< , =, ==, ===, !=,!==,>=,<=

// const temperature = 41

// if(temperature === 41 ){
//     console.log("less than 50");
  
// }
// else{
//     console.log("greater than 50");
// }
// console.log("code executed");



// const score=100
// if(score>50){
//     let power="fly" // let ki jagah var use kate to code run hota 
//     console.log(`User power is: ${power}`);
    
// }
// console.log(`User power is: ${power}`);



// const balance=1000
// if(balance>500) console.log("test1") , console.log("test2");   //  te kabhi use nahi karna hai
 

//******************** Nested statement ***************** */

// const balance=1000
// if(balance<500){
//    console.log("less than ");
   
// }
// else if(balance<750){
//     console.log("less than 750");
    
// }
// else if(balance<900){
//     console.log("less than 900");
    
// }
// else{
//     console.log("equal 1000");
    
// }


// *************  real world problem **********88
// const userLoggedIn = true
// const debitCard = true
// const userLoggedInFromGoogle=false
// const userLoggedInFromEmail=true
// if(userLoggedIn && debitCard && userLoggedInFromGoogle){
//     console.log("Allow to buy course");
// }

// if(userLoggedInFromEmail || userLoggedInFromGoogle){
//     console.log("user logged in");
    
// }


/// ################### switch statement################


const month=2

switch(month){
  case 1:
     console.log("Jaunary");
     break
  case 2:
     console.log("feb");
     break
  case 3:
     console.log("march");
     break
   default:
    console.log("default case match");
    break
    

}