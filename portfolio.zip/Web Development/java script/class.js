// function chai(a,b){
//     if(a%2==0){
       
//    if (b%2==0) {
//          console.log(true);
//     } 
        
//     else{
//         console.log(false);
        
//     }
// }
// }
// chai(4,2)

let a=Number(prompt("enter the number:"))
let b=Number(prompt("enter the number:"))
let c=Number(prompt("enter the number:"))
sum=a+b+c

console.log(sum);
avg=(a+b+c)/3
console.log(avg);

