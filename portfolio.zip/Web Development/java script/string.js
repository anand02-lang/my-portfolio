const name = "anand";
const repoCount = 50;

// console.log(name +repoCount + " value");
console.log(`${name} ${repoCount}`);
const gameName = new String ('anan_d')//string declaretion
console.log(gameName[1]);
console.log(gameName.__proto__) 
console.log(gameName.length);
console.log(gameName.toUpperCase());
console.log(gameName.charAt(2));
console.log(gameName.indexOf('n'));

const newString = gameName.substring(0 , 6)//negative value ko ignore karta hai
console.log(newString);

const anotherString = gameName.slice(-6 , 4)//negative value leta hai
console.log(anotherString);

 const newStringOne = "     anand    "
 console.log(newStringOne);
 console.log(newStringOne.trim());// trim space nahi leta hai

const url = "https://anand.com/anand sharma" 
console.log(url.replace(' ' , '_'));
console.log(url.includes('anand')); //url me anand hai ya nahi

 console.log(gameName.split('_'));// convert string to array


 

